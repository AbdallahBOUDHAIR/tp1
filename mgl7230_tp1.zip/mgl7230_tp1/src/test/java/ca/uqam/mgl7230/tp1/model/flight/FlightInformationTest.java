import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import ca.uqam.mgl7230.tp1.model.flight.FlightInformation;
import ca.uqam.mgl7230.tp1.model.plane.PlaneType;

class FlightInformationTest {

    @Test
    void testFlightInformationCreation() {
        FlightInformation flight = new FlightInformation("UQAM123",
                45.508888, -73.561668, 48.864716, 2.349014, PlaneType.BOEING);

        assertNotNull(flight);
        assertEquals("UQAM123", flight.getFlightNumber());
        assertEquals(45.508888, flight.getLatSource());
        assertEquals(-73.561668, flight.getLonSource());
        assertEquals(48.864716, flight.getLatDestination());
        assertEquals(2.349014, flight.getLonDestination());
        assertEquals(PlaneType.BOEING, flight.getPlaneType());
    }

    @Test
    void testFlightWithNullFlightNumber() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new FlightInformation(null, 45.508888, -73.561668, 48.864716, 2.349014, PlaneType.AIRBUS);
        });
        assertEquals("Le numéro du vol ne peut pas être vide ou null.", exception.getMessage());
    }

    @Test
    void testFlightWithInvalidCoordinates() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new FlightInformation("UQAM124", 100.0, -200.0, 95.0, 190.0, PlaneType.BOMBARDIER);
        });
        assertNotNull(exception);
    }

    @Test
    void testFlightWithNoPlaneType() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new FlightInformation("UQAM125", 45.508888, -73.561668, 48.864716, 2.349014, null);
        });
        assertEquals("Le type d'avion ne peut pas être null.", exception.getMessage());
    }
}

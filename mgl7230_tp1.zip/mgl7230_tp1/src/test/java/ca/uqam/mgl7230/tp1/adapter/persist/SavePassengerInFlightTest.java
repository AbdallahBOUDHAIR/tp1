import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

import java.io.FileWriter;
import java.io.IOException;

import ca.uqam.mgl7230.tp1.model.passenger.Passenger;
import ca.uqam.mgl7230.tp1.model.passenger.EconomyClassPassenger;
import ca.uqam.mgl7230.tp1.adapter.persist.SavePassengerInFlight;
import org.mockito.InOrder;

class SavePassengerInFlightTest {

    @Test
    void testSavePassengerInFlight() throws IOException {
        // Mock du FileWriter
        FileWriter fileWriterMock = mock(FileWriter.class);
        when(fileWriterMock.append(anyString())).thenReturn(fileWriterMock);

        SavePassengerInFlight saver = new SavePassengerInFlight();

        // Création d'un passager test
        Passenger passenger = new EconomyClassPassenger("A12345", "Alice", 30, 500);

        // Enregistrer le passager dans le vol
        saver.save(fileWriterMock, passenger, "UQAM001");

        // Vérification de l'ordre d'écriture avec inOrder()
        InOrder inOrder = inOrder(fileWriterMock);
        inOrder.verify(fileWriterMock).append("UQAM001");
        inOrder.verify(fileWriterMock).append(",");
        inOrder.verify(fileWriterMock).append("A12345");
        inOrder.verify(fileWriterMock).append(",");
        inOrder.verify(fileWriterMock).append("Alice");
        inOrder.verify(fileWriterMock).append(",");
        inOrder.verify(fileWriterMock).append("30");
        inOrder.verify(fileWriterMock).append(",");
        inOrder.verify(fileWriterMock).append("ECONOMY_CLASS");
        inOrder.verify(fileWriterMock).append(",");
        inOrder.verify(fileWriterMock).append("500");
        inOrder.verify(fileWriterMock).append("\n");

        // Vérification que le fichier est bien flushé après l’écriture
        verify(fileWriterMock).flush();
    }
}

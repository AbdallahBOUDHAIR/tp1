package ca.uqam.mgl7230.tp1.utils;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import ca.uqam.mgl7230.tp1.model.flight.FlightInformation;  // Import du modèle des vols
import ca.uqam.mgl7230.tp1.model.plane.PlaneType;  // Import du modèle des avions



class DistanceCalculatorTest {


    @Test
    void testDistanceBetweenMontrealAndParis() {
        DistanceCalculator calculator = new DistanceCalculator();
        FlightInformation flight = new FlightInformation("UQAM001",
                45.508888, -73.561668, 48.864716, 2.349014, PlaneType.BOEING);

        int distance = calculator.calculate(flight);
        assertEquals(5520, distance, 100); // Tolérance de 100 km
    }

    @Test
    void testDistanceBetweenSamePoint() {
        DistanceCalculator calculator = new DistanceCalculator();
        FlightInformation flight = new FlightInformation("UQAM002",
                40.712776, -74.005974, 40.712776, -74.005974, PlaneType.AIRBUS);

        int distance = calculator.calculate(flight);
        assertEquals(0, distance);
    }
    @Test
    void testDistanceBetweenAntipodalPoints() {
        DistanceCalculator calculator = new DistanceCalculator();
        FlightInformation flight = new FlightInformation("UQAM003",
                0.0, 0.0, -0.0, 180.0, PlaneType.EMBRAER);

        int distance = calculator.calculate(flight);
        assertEquals(20015, distance, 50); // Tolérance de 50 km
    }
    @Test
    void testDistanceBetweenNewYorkAndLondon() {
        DistanceCalculator calculator = new DistanceCalculator();
        FlightInformation flight = new FlightInformation("UQAM004",
                40.712776, -74.005974, 51.507351, -0.127758, PlaneType.BOMBARDIER);

        int distance = calculator.calculate(flight);
        assertEquals(5570, distance, 100); // Tolérance de 100 km


    }

    @Test
    void testDistanceBetweenTokyoAndSydney() {
        DistanceCalculator calculator = new DistanceCalculator();
        FlightInformation flight = new FlightInformation("UQAM005",
                35.652832, 139.839478, -33.868820, 151.209290, PlaneType.AIRBUS);

        int distance = calculator.calculate(flight);
        assertEquals(7820, distance, 100); // Tolérance de 100 km
    }

}
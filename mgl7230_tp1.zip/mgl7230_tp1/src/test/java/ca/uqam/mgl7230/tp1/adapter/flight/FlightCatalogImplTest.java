import ca.uqam.mgl7230.tp1.exception.FlightNotFoundException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import ca.uqam.mgl7230.tp1.adapter.flight.FlightCatalogImpl;
import ca.uqam.mgl7230.tp1.adapter.flight.FlightCatalog;
import ca.uqam.mgl7230.tp1.model.flight.FlightInformation;

import ca.uqam.mgl7230.tp1.model.plane.PlaneType;

class FlightCatalogImplTest {

    @Test
    void testGetExistingFlightInformation() {
        FlightCatalog flightCatalog = new FlightCatalogImpl();
        FlightInformation flight = flightCatalog.getFlightInformation("UQAM001");

        assertNotNull(flight);
        assertEquals("UQAM001", flight.getFlightNumber());
        assertEquals(45.508888, flight.getLatSource());
        assertEquals(-73.561668, flight.getLonSource());
        assertEquals(PlaneType.BOEING, flight.getPlaneType());
    }

    @Test
    void testGetNonExistingFlightInformation() {
        FlightCatalog flightCatalog = new FlightCatalogImpl();
        Exception exception = assertThrows(FlightNotFoundException.class, () -> {
            flightCatalog.getFlightInformation("INVALID_FLIGHT");
        });
        assertNotNull(exception);
    }

    @Test
    void testGetFlightInformationWithNull() {
        FlightCatalog flightCatalog = new FlightCatalogImpl();
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            flightCatalog.getFlightInformation(null);
        });
        assertNotNull(exception);
    }

    @Test
    void testAddAndRetrieveFlightInformation() {
        FlightCatalogImpl flightCatalog = new FlightCatalogImpl();

        // Créer un nouvel objet FlightInformation
        FlightInformation newFlight = new FlightInformation("UQAM999",
                40.712776, -74.005974, 34.052235, -118.243683, PlaneType.AIRBUS);

        // Correction : Passer le numéro de vol + FlightInformation
        flightCatalog.addFlight("UQAM999", newFlight);

        // Vérifier que le vol ajouté est bien récupérable
        FlightInformation retrievedFlight = flightCatalog.getFlightInformation("UQAM999");
        assertNotNull(retrievedFlight);
        assertEquals("UQAM999", retrievedFlight.getFlightNumber());
        assertEquals(40.712776, retrievedFlight.getLatSource());
        assertEquals(-74.005974, retrievedFlight.getLonSource());
        assertEquals(PlaneType.AIRBUS, retrievedFlight.getPlaneType());
    }
}

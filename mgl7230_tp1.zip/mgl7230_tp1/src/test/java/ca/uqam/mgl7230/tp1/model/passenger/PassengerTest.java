import org.junit.jupiter.api.Test;  // Import JUnit 5
import static org.junit.jupiter.api.Assertions.*;  // Assertions JUnit

import ca.uqam.mgl7230.tp1.model.passenger.Passenger;  // Classe abstraite à tester
import ca.uqam.mgl7230.tp1.model.passenger.EconomyClassPassenger;  // Sous-classe Economy
import ca.uqam.mgl7230.tp1.model.passenger.BusinessClassPassenger;  // Sous-classe Business
import ca.uqam.mgl7230.tp1.model.passenger.FirstClassPassenger;  // Sous-classe First
import ca.uqam.mgl7230.tp1.model.passenger.PassengerClass;  // Enum des classes de passagers

class PassengerTest {

    @Test
    void testEconomyPassengerCreation() {
        Passenger passenger = new EconomyClassPassenger("A12345", "Alice", 30, 500);

        assertNotNull(passenger);
        assertEquals("A12345", passenger.getPassport());
        assertEquals("Alice", passenger.getName());
        assertEquals(30, passenger.getAge());
        assertEquals(500, passenger.getMillagePoints());
        assertEquals(PassengerClass.ECONOMY_CLASS, passenger.getType());
    }

    @Test
    void testBusinessPassengerCreation() {
        Passenger passenger = new BusinessClassPassenger("B67890", "Bob", 40, 1000);

        assertNotNull(passenger);
        assertEquals("B67890", passenger.getPassport());
        assertEquals("Bob", passenger.getName());
        assertEquals(40, passenger.getAge());
        assertEquals(1000, passenger.getMillagePoints());
        assertEquals(PassengerClass.BUSINESS_CLASS, passenger.getType());
    }

    @Test
    void testFirstClassPassengerCreation() {
        Passenger passenger = new FirstClassPassenger("C13579", "Charlie", 35, 1500);

        assertNotNull(passenger);
        assertEquals("C13579", passenger.getPassport());
        assertEquals("Charlie", passenger.getName());
        assertEquals(35, passenger.getAge());
        assertEquals(1500, passenger.getMillagePoints());
        assertEquals(PassengerClass.FIRST_CLASS, passenger.getType());
    }

    @Test
    void testPassengerWithNullPassport() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new EconomyClassPassenger(null, "Alice", 30, 500);
        });
        assertNotNull(exception);
    }

    @Test
    void testPassengerWithNegativeAge() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new BusinessClassPassenger("X98765", "John", -5, 200);
        });
        assertNotNull(exception);
    }
}

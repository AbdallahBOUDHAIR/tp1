package ca.uqam.mgl7230.tp1.exception;

/**
 * Exception levée lorsqu'un type de passager est introuvable.
 */
public class PassengerTypeNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L; // Assure la compatibilité de la classe pour la sérialisation

    /**
     * Constructeur avec un message personnalisé.
     *
     * @param passengerType Le type de passager introuvable.
     */
    public PassengerTypeNotFoundException(String passengerType) {
        super("Le type de passager spécifié est introuvable : " + passengerType);
    }

    /**
     * Constructeur avec un message et une cause d'erreur.
     *
     * @param passengerType Le type de passager introuvable.
     * @param cause         La cause sous-jacente de l'erreur.
     */
    public PassengerTypeNotFoundException(String passengerType, Throwable cause) {
        super("Le type de passager spécifié est introuvable : " + passengerType, cause);
    }
}

package ca.uqam.mgl7230.tp1.adapter.persist;

import ca.uqam.mgl7230.tp1.model.passenger.Passenger;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Service pour sauvegarder les passagers dans un fichier CSV.
 */
public class SavePassengerInFlight {
    private static final Logger logger = Logger.getLogger(SavePassengerInFlight.class.getName());

    /**
     * Sauvegarde un passager dans un fichier en utilisant son nom.
     *
     * @param fileName    Nom du fichier CSV.
     * @param passenger   Passager à enregistrer.
     * @param flightNumber Numéro du vol.
     */
    public void save(String fileName, Passenger passenger, String flightNumber) {
        try (FileWriter file = new FileWriter(fileName, true)) {
            writePassengerData(file, passenger, flightNumber);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Erreur lors de l'enregistrement du passager dans " + fileName, e);
        }
    }

    /**
     * Sauvegarde un passager en utilisant un `FileWriter` existant.
     *
     * @param file        FileWriter ouvert pour l'écriture.
     * @param passenger   Passager à enregistrer.
     * @param flightNumber Numéro du vol.
     */
    public void save(FileWriter file, Passenger passenger, String flightNumber) {
        try {
            writePassengerData(file, passenger, flightNumber);
            file.flush(); // S'assurer que les données sont bien écrites
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Erreur lors de l'écriture du passager " + passenger.getPassport(), e);
        }
    }

    /**
     * Écrit les informations d'un passager dans le fichier CSV.
     *
     * @param file        FileWriter pour l'écriture.
     * @param passenger   Passager à enregistrer.
     * @param flightNumber Numéro du vol.
     * @throws IOException En cas d'erreur d'écriture.
     */
    private void writePassengerData(FileWriter file, Passenger passenger, String flightNumber) throws IOException {
        file.append(flightNumber)
                .append(",")
                .append(passenger.getPassport())
                .append(",")
                .append(passenger.getName())
                .append(",")
                .append(String.valueOf(passenger.getAge()))
                .append(",")
                .append(String.valueOf(passenger.getType()))
                .append(",")
                .append(String.valueOf(passenger.getMillagePoints()))
                .append("\n");
    }
}

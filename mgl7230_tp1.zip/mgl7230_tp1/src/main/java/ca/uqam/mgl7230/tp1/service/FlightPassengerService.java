package ca.uqam.mgl7230.tp1.service;

import ca.uqam.mgl7230.tp1.adapter.flight.FlightCatalog;
import ca.uqam.mgl7230.tp1.adapter.plane.PlaneCatalog;
import ca.uqam.mgl7230.tp1.exception.FlightNotFoundException;
import ca.uqam.mgl7230.tp1.model.flight.FlightInformation;
import ca.uqam.mgl7230.tp1.model.passenger.Passenger;
import ca.uqam.mgl7230.tp1.model.passenger.PassengerClass;
import ca.uqam.mgl7230.tp1.model.plane.PlaneType;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Service de gestion des passagers pour un vol donné.
 */
public class FlightPassengerService {
    private static final Logger logger = Logger.getLogger(FlightPassengerService.class.getName());

    private int totalAmountFirstClassSeats;
    private int totalAmountBusinessClassSeats;
    private int totalAmountEconomyClassSeats;

    /**
     * Initialise le service avec les informations du vol et du type d'avion.
     *
     * @param planeCatalog  Catalogue des avions.
     * @param flightCatalog Catalogue des vols.
     * @param flightNumber  Numéro du vol.
     * @throws FlightNotFoundException si le vol n'existe pas.
     */
    public FlightPassengerService(PlaneCatalog planeCatalog, FlightCatalog flightCatalog, String flightNumber) {
        if (planeCatalog == null || flightCatalog == null || flightNumber == null || flightNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Les paramètres fournis ne peuvent pas être null ou vides.");
        }

        FlightInformation flightInfo = flightCatalog.getFlightInformation(flightNumber);
        if (flightInfo == null) {
            throw new FlightNotFoundException(flightNumber);
        }

        PlaneType planeType = flightInfo.getPlaneType();
        this.totalAmountFirstClassSeats = planeCatalog.getNumberSeatsFirstClass(planeType);
        this.totalAmountBusinessClassSeats = planeCatalog.getNumberSeatsBusinessClass(planeType);
        this.totalAmountEconomyClassSeats = planeCatalog.getNumberSeatsEconomyClass(planeType);
    }

    /**
     * Ajoute un passager au vol et met à jour le nombre de sièges disponibles.
     *
     * @param passenger Le passager à ajouter.
     */
    public void addPassenger(Passenger passenger) {
        if (passenger == null) {
            throw new IllegalArgumentException("Le passager ne peut pas être null.");
        }

        PassengerClass type = passenger.getType();
        switch (type) {
            case FIRST_CLASS -> {
                if (totalAmountFirstClassSeats > 0) {
                    totalAmountFirstClassSeats--;
                    logger.info("Passager ajouté en Première Classe.");
                } else {
                    logger.warning("Aucun siège disponible en Première Classe.");
                }
            }
            case BUSINESS_CLASS -> {
                if (totalAmountBusinessClassSeats > 0) {
                    totalAmountBusinessClassSeats--;
                    logger.info("Passager ajouté en Classe Affaires.");
                } else {
                    logger.warning("Aucun siège disponible en Classe Affaires.");
                }
            }
            case ECONOMY_CLASS -> {
                if (totalAmountEconomyClassSeats > 0) {
                    totalAmountEconomyClassSeats--;
                    logger.info("Passager ajouté en Classe Économie.");
                } else {
                    logger.warning("Aucun siège disponible en Classe Économie.");
                }
            }
            default -> {
                logger.log(Level.SEVERE, "Type de passager inconnu : " + type);
                throw new IllegalArgumentException("Type de passager non valide.");
            }
        }
    }

    /**
     * Retourne le nombre de sièges disponibles en Première Classe.
     *
     * @return Nombre de sièges disponibles en Première Classe.
     */
    public int numberOfFirstClassSeatsAvailable() {
        return totalAmountFirstClassSeats;
    }

    /**
     * Retourne le nombre de sièges disponibles en Classe Affaires.
     *
     * @return Nombre de sièges disponibles en Classe Affaires.
     */
    public int numberOfBusinessClassSeatsAvailable() {
        return totalAmountBusinessClassSeats;
    }

    /**
     * Retourne le nombre de sièges disponibles en Classe Économie.
     *
     * @return Nombre de sièges disponibles en Classe Économie.
     */
    public int numberOfEconomyClassSeatsAvailable() {
        return totalAmountEconomyClassSeats;
    }

    /**
     * Retourne le nombre total de sièges disponibles.
     *
     * @return Nombre total de sièges disponibles.
     */
    public int numberOfTotalSeatsAvailable() {
        return totalAmountFirstClassSeats + totalAmountBusinessClassSeats + totalAmountEconomyClassSeats;
    }
}

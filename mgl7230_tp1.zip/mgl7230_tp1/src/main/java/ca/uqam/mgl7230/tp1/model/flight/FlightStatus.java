package ca.uqam.mgl7230.tp1.model.flight;

public enum FlightStatus {

    FULL,
    CANCELED,
    OPEN
}

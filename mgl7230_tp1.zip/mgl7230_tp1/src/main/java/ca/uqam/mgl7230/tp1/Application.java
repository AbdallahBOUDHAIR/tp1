package ca.uqam.mgl7230.tp1;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import ca.uqam.mgl7230.tp1.adapter.flight.FlightCatalog;
import ca.uqam.mgl7230.tp1.adapter.flight.FlightCatalogImpl;
import ca.uqam.mgl7230.tp1.adapter.persist.SavePassengerInFlight;
import ca.uqam.mgl7230.tp1.adapter.plane.PlaneCatalog;
import ca.uqam.mgl7230.tp1.adapter.plane.PlaneCatalogImpl;
import ca.uqam.mgl7230.tp1.config.FileWriterProvider;
import ca.uqam.mgl7230.tp1.model.passenger.Passenger;
import ca.uqam.mgl7230.tp1.model.passenger.PassengerKeyConstants;
import ca.uqam.mgl7230.tp1.service.*;
import ca.uqam.mgl7230.tp1.service.prompt.FlightPromptService;
import ca.uqam.mgl7230.tp1.service.prompt.PassengerPromptService;
import ca.uqam.mgl7230.tp1.utils.DistanceCalculator;


/**
 * Application principale pour la gestion des réservations de vols.
 */

public class Application {
    private static final Logger logger = Logger.getLogger(Application.class.getName());

    public static void main(String[] args) {
        logger.info("Service started...");

        try {
            runApplication();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Erreur lors du démarrage de l'application", e);
        }
    }

    /**
     * Initialise et exécute le processus de réservation de passagers.
     *
     * @throws IOException En cas d'erreur d'écriture dans le fichier.
     */
    private static void runApplication() throws IOException {
        try (Scanner scanner = new Scanner(System.in);
             FileWriter file = new FileWriterProvider().createFile("passengerData.csv")) {

            InitializeResult result = initialize(scanner, file);
            boolean shouldContinue = true;

            while (shouldContinue) {
                Passenger passenger = collectPassengerData(result);
                if (passenger == null) {
                    logger.warning("Erreur lors de la création du passager. Veuillez réessayer.");
                    continue;
                }

                // Réserver et sauvegarder le passager
                BookingService bookingService = new BookingService(result.flightPassengerService(), new PassengerService(result.distanceCalculator()));
                bookingService.book(passenger, result.flightCatalog().getFlightInformation(result.flightNumber()));
                result.savePassengerInFlight().save("passengerData.csv", passenger, result.flightNumber());

                logger.info("Seats available: " + result.flightPassengerService().numberOfTotalSeatsAvailable());
                logger.info("Continue adding passengers to this flight? yes or no");

                if ("no".equalsIgnoreCase(scanner.nextLine())) {
                    shouldContinue = false;
                }
            }
        }
    }

    /**
     * Initialise les services nécessaires pour l'application.
     *
     * @param scanner Scanner pour l'entrée utilisateur.
     * @param file    Fichier pour l'enregistrement des passagers.
     * @return Un objet `InitializeResult` contenant les services initialisés.
     * @throws IOException En cas d'erreur d'accès au fichier.
     */
    private static InitializeResult initialize(Scanner scanner, FileWriter file) throws IOException {
        DistanceCalculator distanceCalculator = new DistanceCalculator();
        PlaneCatalog planeCatalog = new PlaneCatalogImpl();
        FlightCatalog flightCatalog = new FlightCatalogImpl();
        SavePassengerInFlight savePassengerInFlight = new SavePassengerInFlight();
        FlightPromptService flightPromptService = new FlightPromptService(flightCatalog);
        String flightNumber = flightPromptService.getFlightInformation(scanner).getFlightNumber();
        FlightPassengerService flightPassengerService = new FlightPassengerService(planeCatalog, flightCatalog, flightNumber);

        return new InitializeResult(distanceCalculator, scanner, flightCatalog, file, savePassengerInFlight, flightNumber, flightPassengerService);
    }

    /**
     * Collecte les données d'un passager via l'entrée utilisateur.
     *
     * @param result Résultat de l'initialisation contenant les services.
     * @return Un objet `Passenger` représentant le passager ou `null` en cas d'erreur.
     */
    private static Passenger collectPassengerData(InitializeResult result) {
        try {
            PassengerPromptService passengerPromptService = new PassengerPromptService();
            Map<PassengerKeyConstants, Object> passengerData = passengerPromptService.getPassengerData(result.scanner());
            PassengerService passengerService = new PassengerService(result.distanceCalculator());
            return passengerService.createPassenger(result.flightCatalog().getFlightInformation(result.flightNumber()), passengerData);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Erreur lors de la collecte des informations du passager", e);
            return null;
        }
    }

    /**
     * Classe d'enregistrement pour stocker les services initiaux de l'application.
     *
     * @param distanceCalculator      Service de calcul de distance.
     * @param scanner                 Scanner pour l'entrée utilisateur.
     * @param flightCatalog           Catalogue des vols.
     * @param file                    Fichier pour enregistrer les passagers.
     * @param savePassengerInFlight   Service de sauvegarde des passagers.
     * @param flightNumber            Numéro du vol sélectionné.
     * @param flightPassengerService  Service de gestion des passagers pour un vol donné.
     */
    private record InitializeResult(DistanceCalculator distanceCalculator, Scanner scanner, FlightCatalog flightCatalog, FileWriter file, SavePassengerInFlight savePassengerInFlight, String flightNumber, FlightPassengerService flightPassengerService) {
    }
}
package ca.uqam.mgl7230.tp1.model.passenger;

public enum PassengerKeyConstants {

    PASSENGER_PASSPORT,
    PASSENGER_NAME,
    PASSENGER_AGE,
    PASSENGER_CLASS;

}

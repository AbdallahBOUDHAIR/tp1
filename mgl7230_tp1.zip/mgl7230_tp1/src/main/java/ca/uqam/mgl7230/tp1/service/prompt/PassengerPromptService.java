package ca.uqam.mgl7230.tp1.service.prompt;

import ca.uqam.mgl7230.tp1.exception.PassengerTypeNotFoundException;
import ca.uqam.mgl7230.tp1.model.passenger.PassengerClass;
import ca.uqam.mgl7230.tp1.model.passenger.PassengerKeyConstants;

import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PassengerPromptService {
    private static final Logger logger = Logger.getLogger(PassengerPromptService.class.getName());

    public Map<PassengerKeyConstants, Object> getPassengerData(Scanner scanner) {
        try {
            System.out.print("Enter Passenger passport: ");
            String passengerPassport = scanner.nextLine().trim();
            if (passengerPassport.isEmpty()) {
                throw new IllegalArgumentException("Le passeport du passager ne peut pas être vide.");
            }

            System.out.print("Enter Passenger name: ");
            String passengerName = scanner.nextLine().trim();
            if (passengerName.isEmpty()) {
                throw new IllegalArgumentException("Le nom du passager ne peut pas être vide.");
            }

            System.out.print("Enter Passenger age: ");
            int passengerAge;
            try {
                passengerAge = Integer.parseInt(scanner.nextLine().trim());
                if (passengerAge < 0) {
                    throw new IllegalArgumentException("L'âge ne peut pas être négatif.");
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Veuillez entrer un âge valide (nombre entier).", e);
            }

            System.out.print("Enter passenger type (first, business, economy): ");
            String passengerType = scanner.nextLine().trim().toLowerCase();

            PassengerClass passengerClass = getPassengerClass(passengerType);

            return Map.of(
                    PassengerKeyConstants.PASSENGER_PASSPORT, passengerPassport,
                    PassengerKeyConstants.PASSENGER_NAME, passengerName,
                    PassengerKeyConstants.PASSENGER_AGE, passengerAge,
                    PassengerKeyConstants.PASSENGER_CLASS, passengerClass
            );
        } catch (IllegalArgumentException e) {
            logger.log(Level.SEVERE, "Erreur lors de la saisie des données du passager : " + e.getMessage(), e);
            throw e; // Propage l'exception pour permettre une gestion plus haut niveau
        }
    }

    private static PassengerClass getPassengerClass(String passengerType) {
        switch (passengerType) {
            case "first" -> {
                return PassengerClass.FIRST_CLASS;
            }
            case "business" -> {
                return PassengerClass.BUSINESS_CLASS;
            }
            case "economy" -> {
                return PassengerClass.ECONOMY_CLASS;
            }
            default -> throw new PassengerTypeNotFoundException(passengerType);
        }
    }
}

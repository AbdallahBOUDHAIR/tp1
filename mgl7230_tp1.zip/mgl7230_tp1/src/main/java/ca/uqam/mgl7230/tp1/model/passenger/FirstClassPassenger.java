package ca.uqam.mgl7230.tp1.model.passenger;

import java.util.Objects;

/**
 * Représente un passager en Première Classe.
 */
public class FirstClassPassenger extends Passenger {

    /**
     * Constructeur avec validation des données.
     *
     * @param passport       Le numéro de passeport (non null, non vide).
     * @param name           Le nom du passager (non null, non vide).
     * @param age            L'âge du passager (doit être ≥ 0).
     * @param millagePoints  Les points de fidélité accumulés.
     * @throws IllegalArgumentException si une donnée est invalide.
     */
    public FirstClassPassenger(String passport, String name, int age, int millagePoints) {
        super(passport, name, age, millagePoints);
        if (passport == null || passport.trim().isEmpty()) {
            throw new IllegalArgumentException("Le passeport ne peut pas être null ou vide.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Le nom du passager ne peut pas être null ou vide.");
        }
        if (age < 0) {
            throw new IllegalArgumentException("L'âge ne peut pas être négatif.");
        }
    }

    @Override
    public PassengerClass getType() {
        return PassengerClass.FIRST_CLASS;
    }

    @Override
    public String toString() {
        return String.format("FirstClassPassenger{passport='%s', name='%s', age=%d, millagePoints=%d}",
                getPassport(), getName(), getAge(), getMillagePoints());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        FirstClassPassenger that = (FirstClassPassenger) obj;
        return getAge() == that.getAge() &&
                getMillagePoints() == that.getMillagePoints() &&
                getPassport().equals(that.getPassport()) &&
                getName().equals(that.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getPassport(), getName(), getAge(), getMillagePoints());
    }
}

package ca.uqam.mgl7230.tp1.model.passenger;

public enum PassengerClass {

    FIRST_CLASS,
    BUSINESS_CLASS,
    ECONOMY_CLASS
}

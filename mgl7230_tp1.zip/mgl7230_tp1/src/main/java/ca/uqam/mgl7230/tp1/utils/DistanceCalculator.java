package ca.uqam.mgl7230.tp1.utils;

import ca.uqam.mgl7230.tp1.model.flight.FlightInformation;
import java.util.logging.Logger;

/**
 * Utilitaire pour calculer la distance entre deux points géographiques.
 */
public class DistanceCalculator {
    private static final Logger logger = Logger.getLogger(DistanceCalculator.class.getName());
    private static final double EARTH_RADIUS_KM = 6371.0; // Rayon moyen de la Terre en km

    /**
     * Calcule la distance entre l'origine et la destination d'un vol.
     *
     * @param flightInformation Les informations du vol.
     * @return La distance en kilomètres.
     * @throws IllegalArgumentException si les coordonnées du vol sont invalides.
     */
    public int calculate(FlightInformation flightInformation) {
        if (flightInformation == null) {
            logger.warning("FlightInformation est null. Impossible de calculer la distance.");
            throw new IllegalArgumentException("FlightInformation ne peut pas être null.");
        }

        // Vérification des valeurs nulles ou invalides
        if (flightInformation.getLatSource() == null || flightInformation.getLonSource() == null ||
                flightInformation.getLatDestination() == null || flightInformation.getLonDestination() == null) {
            logger.warning("Coordonnées de vol invalides : " + flightInformation);
            throw new IllegalArgumentException("Les coordonnées de vol ne peuvent pas être nulles.");
        }

        int distance = computeDistance(
                flightInformation.getLatSource(), flightInformation.getLonSource(),
                flightInformation.getLatDestination(), flightInformation.getLonDestination()
        );

        logger.info("Distance calculée pour le vol " + flightInformation.getFlightNumber() + " : " + distance + " km");
        return distance;
    }

    /**
     * Calcule la distance entre deux points géographiques avec la formule de la sphère.
     *
     * @param lat1 Latitude de départ.
     * @param lon1 Longitude de départ.
     * @param lat2 Latitude d'arrivée.
     * @param lon2 Longitude d'arrivée.
     * @return La distance en kilomètres.
     */
    private int computeDistance(double lat1, double lon1, double lat2, double lon2) {
        lat1 = Math.toRadians(lat1);
        lon1 = Math.toRadians(lon1);
        lat2 = Math.toRadians(lat2);
        lon2 = Math.toRadians(lon2);

        double acosValue = Math.sin(lat1) * Math.sin(lat2) +
                Math.cos(lat1) * Math.cos(lat2) * Math.cos(lon2 - lon1);

        // Correction des erreurs d'arrondi (Checkstyle compliant)
        acosValue = Math.min(1.0, Math.max(-1.0, acosValue));

        return (int) (Math.acos(acosValue) * EARTH_RADIUS_KM);
    }
}

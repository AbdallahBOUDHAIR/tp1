package ca.uqam.mgl7230.tp1.model.passenger;

import java.util.Objects;

/**
 * Classe abstraite représentant un passager.
 */
public abstract class Passenger {

    private final String passport;
    private final String name;
    private final int age;
    private final int millagePoints;

    /**
     * Constructeur avec validation des données.
     *
     * @param passport      Numéro du passeport (non null, non vide).
     * @param name          Nom du passager (non null, non vide).
     * @param age           Âge du passager (doit être ≥ 0).
     * @param millagePoints Points de fidélité accumulés.
     * @throws IllegalArgumentException si une donnée est invalide.
     */
    public Passenger(String passport, String name, int age, int millagePoints) {
        if (passport == null || passport.trim().isEmpty()) {
            throw new IllegalArgumentException("Le passeport ne peut pas être null ou vide.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Le nom du passager ne peut pas être null ou vide.");
        }
        if (age < 0) {
            throw new IllegalArgumentException("L'âge ne peut pas être négatif.");
        }
        if (millagePoints < 0) {
            throw new IllegalArgumentException("Les points de fidélité ne peuvent pas être négatifs.");
        }

        this.passport = passport;
        this.name = name;
        this.age = age;
        this.millagePoints = millagePoints;
    }

    /**
     * Retourne la classe du passager (First, Business, Economy).
     *
     * @return Une valeur de l'énumération PassengerClass.
     */
    public abstract PassengerClass getType();

    public String getPassport() {
        return passport;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getMillagePoints() {
        return millagePoints;
    }

    @Override
    public String toString() {
        return String.format("%s{passport='%s', name='%s', age=%d, millagePoints=%d}",
                getClass().getSimpleName(), passport, name, age, millagePoints);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Passenger passenger = (Passenger) obj;
        return age == passenger.age &&
                millagePoints == passenger.millagePoints &&
                passport.equals(passenger.passport) &&
                name.equals(passenger.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(passport, name, age, millagePoints);
    }
}

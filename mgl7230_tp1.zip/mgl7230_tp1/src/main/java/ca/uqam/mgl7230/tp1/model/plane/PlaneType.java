package ca.uqam.mgl7230.tp1.model.plane;

public enum PlaneType {

    BOEING,
    EMBRAER,
    AIRBUS,
    BOMBARDIER
}

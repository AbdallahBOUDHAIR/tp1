package ca.uqam.mgl7230.tp1.model.flight;

import ca.uqam.mgl7230.tp1.model.plane.PlaneType;
import java.util.Objects;

/**
 * Classe représentant les informations d'un vol.
 */
public class FlightInformation {

    private final String flightNumber;
    private final Double latSource;
    private final Double lonSource;
    private final Double latDestination;
    private final Double lonDestination;
    private final PlaneType planeType;

    /**
     * Constructeur avec validation des données.
     *
     * @param flightNumber  Numéro du vol (non null, non vide).
     * @param latSource     Latitude de départ (-90 à 90).
     * @param lonSource     Longitude de départ (-180 à 180).
     * @param latDestination Latitude de destination (-90 à 90).
     * @param lonDestination Longitude de destination (-180 à 180).
     * @param planeType     Type d'avion utilisé (non null).
     */
    public FlightInformation(String flightNumber, Double latSource, Double lonSource, Double latDestination, Double lonDestination, PlaneType planeType) {
        if (flightNumber == null || flightNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Le numéro du vol ne peut pas être vide ou null.");
        }
        if (!isValidLatitude(latSource) || !isValidLatitude(latDestination)) {
            throw new IllegalArgumentException("Les latitudes doivent être comprises entre -90 et 90.");
        }
        if (!isValidLongitude(lonSource) || !isValidLongitude(lonDestination)) {
            throw new IllegalArgumentException("Les longitudes doivent être comprises entre -180 et 180.");
        }
        if (planeType == null) {
            throw new IllegalArgumentException("Le type d'avion ne peut pas être null.");
        }

        this.flightNumber = flightNumber;
        this.latSource = latSource;
        this.lonSource = lonSource;
        this.latDestination = latDestination;
        this.lonDestination = lonDestination;
        this.planeType = planeType;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public Double getLatSource() {
        return latSource;
    }

    public Double getLonSource() {
        return lonSource;
    }

    public Double getLatDestination() {
        return latDestination;
    }

    public Double getLonDestination() {
        return lonDestination;
    }

    public PlaneType getPlaneType() {
        return planeType;
    }

    /**
     * Vérifie si une latitude est valide.
     *
     * @param latitude Valeur de latitude.
     * @return `true` si valide, `false` sinon.
     */
    private boolean isValidLatitude(Double latitude) {
        return latitude != null && latitude >= -90 && latitude <= 90;
    }

    /**
     * Vérifie si une longitude est valide.
     *
     * @param longitude Valeur de longitude.
     * @return `true` si valide, `false` sinon.
     */
    private boolean isValidLongitude(Double longitude) {
        return longitude != null && longitude >= -180 && longitude <= 180;
    }

    @Override
    public String toString() {
        return String.format("FlightInformation{flightNumber='%s', latSource=%.6f, lonSource=%.6f, latDestination=%.6f, lonDestination=%.6f, planeType=%s}",
                flightNumber, latSource, lonSource, latDestination, lonDestination, planeType);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        FlightInformation that = (FlightInformation) obj;
        return flightNumber.equals(that.flightNumber) &&
                latSource.equals(that.latSource) &&
                lonSource.equals(that.lonSource) &&
                latDestination.equals(that.latDestination) &&
                lonDestination.equals(that.lonDestination) &&
                planeType == that.planeType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(flightNumber, latSource, lonSource, latDestination, lonDestination, planeType);
    }
}

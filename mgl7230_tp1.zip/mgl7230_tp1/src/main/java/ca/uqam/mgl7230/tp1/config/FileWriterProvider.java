package ca.uqam.mgl7230.tp1.config;

import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileWriterProvider {
    private static final Logger logger = Logger.getLogger(FileWriterProvider.class.getName());

    public FileWriter createFile(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty()) {
            logger.severe("Le nom du fichier est invalide ou vide.");
            throw new IllegalArgumentException("Le nom du fichier ne peut pas être vide ou null.");
        }

        try {
            FileWriter fileWriter = new FileWriter(fileName, true); // Append mode
            logger.info("Fichier créé avec succès : " + fileName);
            return fileWriter;
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Erreur lors de la création du fichier : " + fileName, e);
            throw new IOException("Impossible de créer ou d'accéder au fichier : " + fileName, e);
        }
    }
}

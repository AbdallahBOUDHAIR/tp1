package ca.uqam.mgl7230.tp1.adapter.flight;

import ca.uqam.mgl7230.tp1.exception.FlightNotFoundException; // Exception si vol non trouvé
import ca.uqam.mgl7230.tp1.model.flight.FlightInformation; // Classe contenant les informations d'un vol
import ca.uqam.mgl7230.tp1.model.plane.PlaneType; // Enum des types d'avions

import java.util.HashMap; // Pour stocker les vols dans une Map modifiable
import java.util.Map; // Interface de HashMap
import java.util.logging.Level; // Pour gérer les niveaux de log
import java.util.logging.Logger; // Pour afficher les logs du système

public class FlightCatalogImpl implements FlightCatalog {
    private static final Logger logger = Logger.getLogger(FlightCatalogImpl.class.getName());

    // Map contenant les informations des vols
    private final Map<String, FlightInformation> flightInformationMap;

    public FlightCatalogImpl() {
        this.flightInformationMap = new HashMap<>(); // Utilisation d'une Map modifiable

        // Ajout des vols initiaux
        flightInformationMap.put("UQAM001", new FlightInformation("UQAM001", 45.508888, -73.561668, -23.533773, -46.625290, PlaneType.BOEING));
        flightInformationMap.put("UQAM002", new FlightInformation("UQAM002", 45.508888, -73.561668, 35.652832, 139.839478, PlaneType.AIRBUS));
        flightInformationMap.put("UQAM003", new FlightInformation("UQAM003", 45.508888, -73.561668, 48.864716, 2.349014, PlaneType.BOEING));
        flightInformationMap.put("UQAM004", new FlightInformation("UQAM004", 45.508888, -73.561668, 30.033333, 31.233334, PlaneType.BOMBARDIER));
        flightInformationMap.put("UQAM005", new FlightInformation("UQAM005", 45.508888, -73.561668, 31.628674, -7.992047, PlaneType.EMBRAER));
        flightInformationMap.put("UQAM006", new FlightInformation("UQAM006", 45.508888, -73.561668, 41.015137, 28.979530, PlaneType.AIRBUS));
    }

    @Override
    public FlightInformation getFlightInformation(String flightNumber) {
        if (flightNumber == null || flightNumber.trim().isEmpty()) {
            logger.warning("Numéro de vol invalide (null ou vide).");
            throw new IllegalArgumentException("Le numéro de vol ne peut pas être null ou vide.");
        }

        FlightInformation flightInformation = flightInformationMap.get(flightNumber);
        if (flightInformation == null) {
            logger.log(Level.SEVERE, "Vol non trouvé : " + flightNumber);
            throw new FlightNotFoundException(flightNumber);
        }

        logger.info("Vol trouvé : " + flightInformation);
        return flightInformation;
    }

    // Méthode pour ajouter un vol à la Map
    public void addFlight(String flightNumber, FlightInformation flightInformation) {
        if (flightNumber == null || flightInformation == null) {
            throw new IllegalArgumentException("Le numéro de vol et les informations ne peuvent pas être null.");
        }
        flightInformationMap.put(flightNumber, flightInformation);
        logger.info("Nouveau vol ajouté : " + flightInformation);
    }
}

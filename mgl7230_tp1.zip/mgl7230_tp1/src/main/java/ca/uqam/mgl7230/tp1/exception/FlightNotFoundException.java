package ca.uqam.mgl7230.tp1.exception;

/**
 * Exception levée lorsqu'un vol demandé n'existe pas.
 */
public class FlightNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L; // Pour assurer la compatibilité avec la sérialisation

    /**
     * Constructeur avec un message personnalisé.
     *
     * @param flightNumber Le numéro du vol introuvable.
     */
    public FlightNotFoundException(String flightNumber) {
        super("Vol non trouvé : " + flightNumber);
    }

    /**
     * Constructeur avec un message et une cause d'erreur.
     *
     * @param flightNumber Le numéro du vol introuvable.
     * @param cause        La cause sous-jacente de l'erreur.
     */
    public FlightNotFoundException(String flightNumber, Throwable cause) {
        super("Vol non trouvé : " + flightNumber, cause);
    }
}


package ca.uqam.mgl7230.tp1.model.plane;

import java.util.Objects;

/**
 * Classe représentant les informations d'un avion.
 */
public class PlaneInformation {

    private final int numberSeatsFirstClass;
    private final int numberSeatsBusinessClass;
    private final int numberSeatsEconomyClass;
    private final PlaneType planeType;

    /**
     * Constructeur avec validation des données.
     *
     * @param planeType               Le type d'avion (non null).
     * @param numberSeatsFirstClass   Nombre de sièges en Première Classe (≥ 0).
     * @param numberSeatsBusinessClass Nombre de sièges en Classe Affaires (≥ 0).
     * @param numberSeatsEconomyClass  Nombre de sièges en Classe Économie (≥ 0).
     * @throws IllegalArgumentException si une donnée est invalide.
     */
    public PlaneInformation(PlaneType planeType, int numberSeatsFirstClass, int numberSeatsBusinessClass, int numberSeatsEconomyClass) {
        if (planeType == null) {
            throw new IllegalArgumentException("Le type d'avion ne peut pas être null.");
        }
        if (numberSeatsFirstClass < 0 || numberSeatsBusinessClass < 0 || numberSeatsEconomyClass < 0) {
            throw new IllegalArgumentException("Le nombre de sièges ne peut pas être négatif.");
        }

        this.numberSeatsFirstClass = numberSeatsFirstClass;
        this.numberSeatsBusinessClass = numberSeatsBusinessClass;
        this.numberSeatsEconomyClass = numberSeatsEconomyClass;
        this.planeType = planeType;
    }

    public int getNumberSeatsFirstClass() {
        return numberSeatsFirstClass;
    }

    public int getNumberSeatsBusinessClass() {
        return numberSeatsBusinessClass;
    }

    public int getNumberSeatsEconomyClass() {
        return numberSeatsEconomyClass;
    }

    public PlaneType getPlaneType() {
        return planeType;
    }

    /**
     * Retourne le nombre total de sièges dans l'avion.
     *
     * @return Le nombre total de sièges.
     */
    public int getTotalSeats() {
        return numberSeatsFirstClass + numberSeatsBusinessClass + numberSeatsEconomyClass;
    }

    @Override
    public String toString() {
        return String.format("PlaneInformation{planeType=%s, FirstClass=%d, BusinessClass=%d, EconomyClass=%d, TotalSeats=%d}",
                planeType, numberSeatsFirstClass, numberSeatsBusinessClass, numberSeatsEconomyClass, getTotalSeats());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        PlaneInformation that = (PlaneInformation) obj;
        return numberSeatsFirstClass == that.numberSeatsFirstClass &&
                numberSeatsBusinessClass == that.numberSeatsBusinessClass &&
                numberSeatsEconomyClass == that.numberSeatsEconomyClass &&
                planeType == that.planeType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(planeType, numberSeatsFirstClass, numberSeatsBusinessClass, numberSeatsEconomyClass);
    }
}

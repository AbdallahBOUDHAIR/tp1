package ca.uqam.mgl7230.tp1.service;

import ca.uqam.mgl7230.tp1.exception.PassengerTypeNotFoundException;
import ca.uqam.mgl7230.tp1.model.flight.FlightInformation;
import ca.uqam.mgl7230.tp1.model.passenger.*;
import ca.uqam.mgl7230.tp1.utils.DistanceCalculator;

import java.util.Map;

/**
 * Service de gestion des passagers.
 */
public class PassengerService {

    private final DistanceCalculator distanceCalculator;

    /**
     * Constructeur du service des passagers.
     *
     * @param distanceCalculator Instance utilisée pour calculer les points de fidélité en fonction de la distance.
     */
    public PassengerService(DistanceCalculator distanceCalculator) {
        if (distanceCalculator == null) {
            throw new IllegalArgumentException("Le calculateur de distance ne peut pas être null.");
        }
        this.distanceCalculator = distanceCalculator;
    }

    /**
     * Crée un passager en fonction des informations fournies.
     *
     * @param flightInformation Informations sur le vol.
     * @param passengerData     Données du passager sous forme de map.
     * @return Un objet `Passenger` correspondant à la classe choisie.
     * @throws IllegalArgumentException        Si les données du passager sont invalides.
     * @throws PassengerTypeNotFoundException  Si le type de passager est inconnu.
     */
    public Passenger createPassenger(FlightInformation flightInformation,
                                     Map<PassengerKeyConstants, Object> passengerData) {
        if (flightInformation == null || passengerData == null) {
            throw new IllegalArgumentException("Les informations du vol et les données du passager ne peuvent pas être null.");
        }

        String passengerPassport = (String) passengerData.get(PassengerKeyConstants.PASSENGER_PASSPORT);
        String passengerName = (String) passengerData.get(PassengerKeyConstants.PASSENGER_NAME);
        Integer passengerAge = (Integer) passengerData.get(PassengerKeyConstants.PASSENGER_AGE);
        PassengerClass passengerClass = (PassengerClass) passengerData.get(PassengerKeyConstants.PASSENGER_CLASS);

        if (passengerPassport == null || passengerPassport.trim().isEmpty()) {
            throw new IllegalArgumentException("Le passeport du passager ne peut pas être null ou vide.");
        }
        if (passengerName == null || passengerName.trim().isEmpty()) {
            throw new IllegalArgumentException("Le nom du passager ne peut pas être null ou vide.");
        }
        if (passengerAge == null || passengerAge < 0) {
            throw new IllegalArgumentException("L'âge du passager ne peut pas être négatif ou null.");
        }
        if (passengerClass == null) {
            throw new PassengerTypeNotFoundException("Type de passager non reconnu.");
        }

        int millagePoints = distanceCalculator.calculate(flightInformation);

        return switch (passengerClass) {
            case FIRST_CLASS -> new FirstClassPassenger(passengerPassport, passengerName, passengerAge, millagePoints);
            case BUSINESS_CLASS -> new BusinessClassPassenger(passengerPassport, passengerName, passengerAge, millagePoints);
            case ECONOMY_CLASS -> new EconomyClassPassenger(passengerPassport, passengerName, passengerAge, millagePoints);
        };
    }
}
